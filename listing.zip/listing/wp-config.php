<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'listing' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'S;<%Ww0lUW@Kc#aOYv-9e$e: (*#.o37/f&}J[bDyzbpI;K16(!nwy1(R/[70JN4' );
define( 'SECURE_AUTH_KEY',  '=GVIhl}Xl/Gr!Nz|9~>[s2rMPSe?7:CDFi9h &q ;]3{ 0bbzvLL!${ee:yeN~Qh' );
define( 'LOGGED_IN_KEY',    '>v&.a|<n^KU`b}+p77XuqdBj%W^G)BV5xsJG?VHPjl7a}bvYT@Ucr^Q!|DDP(mB<' );
define( 'NONCE_KEY',        '7=sg2 z3!13>Iy|N#ms)eT{u=H%v9@`AheZ~IsXo&1i!rahydY$~!/p8y?[u+?gP' );
define( 'AUTH_SALT',        '[ S#yQw--3mNk(6z</;Sk^fz8CHuQ-g_P`=U$%nb:ZgUdAYjNj#|[}n$=?F&Zjpk' );
define( 'SECURE_AUTH_SALT', '6F?Q)Aw@[Q2N8?6>!&X;/ay.8oMYd,}IX$riJYMhTEM>+sq&FO5]~L4_p83@{tMG' );
define( 'LOGGED_IN_SALT',   'jj<x2cQ&RMZ<5[fu hkCaAR$5?a,mt>XGu|f}pRn<9-U-9D[<eL`x,!8nyI4Z)lH' );
define( 'NONCE_SALT',       '<g@yxChO$SKb6}X}g{^tEb~-U2NI|Y4COV%aXw<Z*doVME4edH<RUk%D??EKJku~' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'lt_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
